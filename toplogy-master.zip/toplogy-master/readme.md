This file contains instructions to be used to reproduce the results of the experiments described in the paper entitled
"Message Classification for Generalized Disease Incidence Detection with Topologically Derived Concept Embeddings" by Mark Magumba and Peter Nabende
The archive contains the following vector files in word2vec format:
1. wp2.csv---Wu and Palmer file
2.sja.csv----stojanovic file
3.ky.csv------kyogoku file
4.ky.csv------rada et al file

training and validation data sets in CNF format can be found in /vectors/consolidated
The corresponding source plain source files can be found in /vectors/monolingual/Datasets plain

We employed the word2vec format so we could use the gensim loader, this was useful for some experiments in which we tried to train doc2vec models using
topological vectors as a starting point and in other cases we froze the vectors and attempted to train doc2vec models but these generally performed poorly
and were not mentioned in the paper.

To reproduce the results in the paper simply run the topology-master.py file.
1. To try out different embeddings besides the default wupalmer distance just edit the file path on line 53
2. To try out different data sets just edit the file path on line 59